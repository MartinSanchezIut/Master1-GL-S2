package com.example.tp4;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.room.Room;

import android.content.res.AssetManager;
import android.os.Bundle;
import android.util.JsonReader;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class Planning extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_planning);

        //Ajouté pour l'exercice 4
        //Création d'une instance de la base de données
        AppDataBase db =  Room.databaseBuilder(getApplicationContext(), AppDataBase.class, "bdd_tp_4").allowMainThreadQueries().build();

        //On utilise les méthodes abstraites de l'AppDataBase pour obtenir une instance de DAO
        PlanningDao planningDao = db.planningDao();

        //On utilise les méthodes de l'instance DAO pour intéragir avec la base de données
        //J'ajoute une entité dans ma base de données
        planningDao.createPlanningEntity(new PlanningEntity(3,"Preparation reunion (bdd)", "Preparation reunion (bdd)", "Reunion (bdd)", "Travailler sur dossier (bdd)", "06", "04", "2022"));

        //Pour tous les exercices
        //J'associe un ViewModel (PlanningModel) à ma classe affichant le planning
        PlanningModel model = new ViewModelProvider(this).get(PlanningModel.class);

        //Observent les changements sur les données
        model.getHoraire1().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                TextView texte_1 = (TextView) findViewById(R.id.texte_1);
                texte_1.setText(s);
            }
        });

        model.getHoraire2().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                TextView texte_2 = (TextView) findViewById(R.id.texte_2);
                texte_2.setText(s);
            }
        });

        model.getHoraire3().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                TextView texte_3 = (TextView) findViewById(R.id.texte_3);
                texte_3.setText(s);
            }
        });

        model.getHoraire4().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                TextView texte_4 = (TextView) findViewById(R.id.texte_4);
                texte_4.setText(s);
            }
        });

        model.getJour().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                TextView textView5 = (TextView) findViewById(R.id.textView5);
                textView5.setText(s);
            }
        });

        model.getMois().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                TextView textView6 = (TextView) findViewById(R.id.textView6);
                textView6.setText(s);
            }
        });

        model.getAnnee().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                TextView textView8 = (TextView) findViewById(R.id.textView8);
                textView8.setText(s);
            }
        });

        //L'automatisation de l'actualisation avec un TimerTask
        Timer timer;
        timer = new Timer();
        timer.schedule(new TimerTask(){
            @Override
            public void run() {
                try {
                    InputStream is = getAssets().open("planning.json");
                    int size = is.available();
                    byte[] buffer = new byte[size];
                    is.read(buffer);
                    is.close();
                    String jsonString = new String(buffer, "UTF-8");
                    JSONArray jsonObject = new JSONArray(jsonString);

                    //Je récupère la date du téléphone
                    Date now = new Date();
                    SimpleDateFormat formatter = new SimpleDateFormat("dd");
                    String result = formatter.format(now);

                    //Je m'occupe que du jour, si ce qui est affiché n'est pas à la date d'ajd j'actualise dans le ViewModel
                    if(!model.getJour().equals(result)){
                        JSONObject jsonObject1 = new JSONObject(String.valueOf(jsonObject.getJSONObject(Integer.parseInt(result) -1 )));
                        model.getHoraire1().postValue(jsonObject1.getString("horaire1"));
                        model.getHoraire2().postValue(jsonObject1.getString("horaire2"));
                        model.getHoraire3().postValue(jsonObject1.getString("horaire3"));
                        model.getHoraire4().postValue(jsonObject1.getString("horaire4"));
                        model.getJour().postValue(jsonObject1.getString("jour"));
                        model.getMois().postValue(jsonObject1.getString("mois"));
                        model.getAnnee().postValue(jsonObject1.getString("annee"));
                    }

                } catch (IOException | JSONException e) {
                    e.printStackTrace();
                }
            }
        }, 0, 20000);
        //Actualisation toutes les vingt secondes !

        findViewById(R.id.button_bdd).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Je récupère en bdd une entité PlanningEntity
                PlanningEntity recupBdd = planningDao.findByDate("06","04","2022");

                //J'appelle la méthode d'actualisation dans mon planningmodel pour changer les valeurs
                // avec celles récupérées dans la base de données
                model.miseAJourDepuisBDD(recupBdd);

            }
        });

    }
}