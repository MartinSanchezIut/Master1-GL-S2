package com.example.tp4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Affichage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_affichage);

        TextView textView_nom = (TextView) findViewById(R.id.textView_nom);
        TextView textView_prenom = (TextView) findViewById(R.id.textView_prenom);
        TextView textView_age = (TextView) findViewById(R.id.textView_age);
        TextView textView_phone = (TextView) findViewById(R.id.textView_phone);
        TextView textView_mdp = (TextView) findViewById(R.id.textView_mdp);
        TextView textView_nb = (TextView) findViewById(R.id.textView_nb);

        Intent inscription = getIntent();
        textView_nom.setText(inscription.getExtras().getString("nom"));
        textView_prenom.setText(inscription.getExtras().getString("prenom"));
        textView_age.setText(inscription.getExtras().getString("age"));
        textView_phone.setText(inscription.getExtras().getString("numero"));
        textView_mdp.setText(inscription.getExtras().getString("mdp"));
        textView_nb.setText(inscription.getExtras().getString("nb"));
    }
}