package com.example.tp4;

import android.util.Log;

public class Utilisation {

    public static int nbUtilisation;

    public Utilisation() {}

    //Cette méthode compte le nombre de fois où l'activité Inscription est relancée
    //suite à l'appel de la méthode onResume(), méthode appelée suite à une restauration
    public int NombreUtilisation(){

        nbUtilisation++;
        Log.i("nombre", String.valueOf(nbUtilisation));
        return nbUtilisation;

    }

    public int getNbUtilisation(){
        return nbUtilisation;
    }

}