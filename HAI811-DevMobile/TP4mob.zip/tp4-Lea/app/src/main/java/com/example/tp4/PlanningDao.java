package com.example.tp4;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

//DAO (Data Access Object), fournit les méthodes que le reste de l'application utilise pour intéragir avec les données de la table utilisateur
@Dao
public interface PlanningDao {

    //Récupérer toutes les instances
    @Query("SELECT * FROM planningentity")
    List<PlanningEntity> getAll();

    //Récupérer une instance par sa date (contient quatre horaires et trois trucs pour les dates)
    @Query("SELECT * FROM planningentity WHERE jour LIKE :first AND mois LIKE :middle AND annee LIKE :last")
    PlanningEntity findByDate(String first, String middle, String last);

    //Insérer un seul élément
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void createPlanningEntity(PlanningEntity planningEntity);

}