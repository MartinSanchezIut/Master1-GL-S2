package com.example.tp4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Inscription extends AppCompatActivity {

    Utilisation utilisation = new Utilisation();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inscription);

        //J'écoute les clic sur le bouton soumettre
        findViewById(R.id.button_soum).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //On récupère les informations
                EditText nom = findViewById(R.id.editText_Nom);
                EditText prenom = findViewById(R.id.editText_Prenom);
                EditText age = findViewById(R.id.editText_Age);
                EditText numero = findViewById(R.id.editText_Tel);
                EditText mdp = findViewById(R.id.editText_Mdp);

                //On se prépare à lancer la deuxième activité
                Intent DeuxiemeActivite = new Intent(getApplicationContext(), Affichage.class);

                DeuxiemeActivite.putExtra("nom", nom.getText().toString());
                DeuxiemeActivite.putExtra("prenom", prenom.getText().toString());
                DeuxiemeActivite.putExtra("age", age.getText().toString());
                DeuxiemeActivite.putExtra("numero", numero.getText().toString());
                DeuxiemeActivite.putExtra("mdp", mdp.getText().toString());
                DeuxiemeActivite.putExtra("nb", String.valueOf(utilisation.getNbUtilisation()));

                startActivity(DeuxiemeActivite);

            }
        });

        //J'écoute les clic sur le bouton Affiche Planning
        findViewById(R.id.button_planning).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //On se prépare à lancer la deuxième activité
                Intent TroisiemeActivite = new Intent(getApplicationContext(), Planning.class);
                startActivity(TroisiemeActivite);

            }
        });
    }

    @Override
    public void onResume() {

        super.onResume();
        utilisation.NombreUtilisation();

    }
}