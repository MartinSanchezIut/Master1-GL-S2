package com.example.tp4;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

@Entity
public class PlanningModel extends ViewModel {

    private MutableLiveData<String> horaire1;
    private MutableLiveData<String> horaire2;
    private MutableLiveData<String> horaire3;
    private MutableLiveData<String> horaire4;
    private MutableLiveData<String> jour;
    private MutableLiveData<String> mois;
    private MutableLiveData<String> annee;

    public PlanningModel(){
        this.horaire1 = new MutableLiveData<>();
        this.horaire2 = new MutableLiveData<>();
        this.horaire3 = new MutableLiveData<>();
        this.horaire4 = new MutableLiveData<>();
        this.jour = new MutableLiveData<>();
        this.mois = new MutableLiveData<>();
        this.annee = new MutableLiveData<>();
    }

    public PlanningModel(MutableLiveData<String> horaire1, MutableLiveData<String> horaire2, MutableLiveData<String> horaire3, MutableLiveData<String> horaire4, MutableLiveData<String> jour, MutableLiveData<String> mois, MutableLiveData<String> annee) {
        this.horaire1 = horaire1;
        this.horaire2 = horaire2;
        this.horaire3 = horaire3;
        this.horaire4 = horaire4;
        this.jour = jour;
        this.mois = mois;
        this.annee = annee;
    }

    public MutableLiveData<String> getHoraire1() {
        return horaire1;
    }

    public void setHoraire1(MutableLiveData<String> horaire1) {
        this.horaire1 = horaire1;
    }

    public MutableLiveData<String> getHoraire2() {
        return horaire2;
    }

    public void setHoraire2(MutableLiveData<String> horaire2) {
        this.horaire2 = horaire2;
    }

    public MutableLiveData<String> getHoraire3() {
        return horaire3;
    }

    public void setHoraire3(MutableLiveData<String> horaire3) {
        this.horaire3 = horaire3;
    }

    public MutableLiveData<String> getHoraire4() {
        return horaire4;
    }

    public void setHoraire4(MutableLiveData<String> horaire4) {
        this.horaire4 = horaire4;
    }

    public MutableLiveData<String> getJour() {
        return jour;
    }

    public void setJour(MutableLiveData<String> jour) {
        this.jour = jour;
    }

    public MutableLiveData<String> getMois() {
        return mois;
    }

    public void setMois(MutableLiveData<String> mois) {
        this.mois = mois;
    }

    public MutableLiveData<String> getAnnee() {
        return annee;
    }

    public void setAnnee(MutableLiveData<String> annee) {
        this.annee = annee;
    }

    public void miseAJourDepuisBDD(PlanningEntity entity){

        horaire1.postValue(entity.getHoraire1());
        horaire2.postValue(entity.getHoraire2());
        horaire3.postValue(entity.getHoraire3());
        horaire4.postValue(entity.getHoraire4());
        jour.postValue(entity.getJour());
        mois.postValue(entity.getMois());
        annee.postValue(entity.getAnnee());

    }

}